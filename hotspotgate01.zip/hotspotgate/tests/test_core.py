import json, re, time
import pytest
from dnslib import DNSRecord, QTYPE
from werkzeug.security import generate_password_hash

from app.db import Database, normalize_code
from app.dnsforge import forge_reply
from app.portal import create_app

CFG = {"portal_ip": "192.168.137.1", "subnet": "192.168.137.0/24", "ssid": "Guest-WiFi",
       "secret_key": "test", "admin_password_hash": generate_password_hash("pw"),
       "login_max_failures": 3, "login_window_seconds": 300}


@pytest.fixture()
def db(tmp_path):
    return Database(str(tmp_path / "t.db"))


@pytest.fixture()
def app(db):
    return create_app(CFG, db, mac_lookup=lambda ip: "aa:bb:cc:00:00:01")


def client(app, ip):
    c = app.test_client()
    c.environ_base["REMOTE_ADDR"] = ip
    return c


def test_normalize():
    assert normalize_code(" abcd 2345 ") == "ABCD-2345"
    assert normalize_code("abcd-2345") == "ABCD-2345"


def test_voucher_lifecycle(db):
    code = db.create_vouchers(1, 30)[0]
    s, err = db.redeem(code, "192.168.137.5", "aa:aa")
    assert err is None and s["expires_at"] - s["started_at"] == 1800
    assert db.active_ips() == {"192.168.137.5"}
    # a different device can't reuse it
    assert db.redeem(code, "192.168.137.9", "bb:bb") == (None, "used")
    # same device with new IP resumes
    s2, err = db.redeem(code, "192.168.137.7", "aa:aa")
    assert err is None and s2["id"] == s["id"] and db.active_ips() == {"192.168.137.7"}
    assert db.redeem("NOPE-NOPE", "1.1.1.1") == (None, "invalid")


def test_expiry_and_end(db):
    code = db.create_vouchers(1, 1)[0]
    s, _ = db.redeem(code, "192.168.137.5")
    db._c.execute("UPDATE sessions SET expires_at=? WHERE id=?", (int(time.time()) - 1, s["id"]))
    db._c.commit()
    assert db.active_ips() == set()
    assert db.expire_due() == 1
    assert db.redeem(code, "192.168.137.5") == (None, "used")      # expired voucher can't restart


def test_unauthorised_is_redirected_to_portal(app):
    c = client(app, "192.168.137.20")
    for path in ["/", "/generate_204", "/hotspot-detect.html", "/anything/else"]:
        r = c.get(path, headers={"Host": "example.com"})
        assert r.status_code == 302 and r.headers["Location"] == "http://192.168.137.1/login"
    assert b"Connect to Guest-WiFi" in c.get("/login").data


def test_login_flow_and_probes(app, db):
    code = db.create_vouchers(1, 60)[0]
    c = client(app, "192.168.137.21")
    r = c.post("/login", data={"code": code.lower()})
    assert r.status_code == 302 and r.headers["Location"].endswith("/status")
    assert b"You're online" in c.get("/status").data
    assert c.get("/generate_204").status_code == 204
    assert c.get("/connecttest.txt").data == b"Success"
    assert c.get("/login").status_code == 302
    c.post("/logout")
    assert db.active_ips() == set()


def test_bad_codes_throttle(app):
    c = client(app, "192.168.137.22")
    for _ in range(3):
        assert c.post("/login", data={"code": "AAAA-BBBB"}).status_code == 400
    assert c.post("/login", data={"code": "AAAA-BBBB"}).status_code == 429


def test_admin_is_host_only_and_csrf_protected(app, db):
    assert client(app, "192.168.137.30").get("/admin").status_code == 404
    host = client(app, "192.168.137.1")
    assert host.get("/admin").status_code == 302                    # to /admin/login
    assert host.post("/admin/login", data={"password": "bad"}).status_code == 200
    assert host.post("/admin/login", data={"password": "pw"}).status_code == 302
    page = host.get("/admin").get_data(as_text=True)
    csrf = re.search(r'name="csrf" value="([0-9a-f]+)"', page).group(1)
    assert host.post("/admin/vouchers", data={"count": 2, "minutes": 60}).status_code == 400   # no csrf
    r = host.post("/admin/vouchers", data={"count": 2, "minutes": 60, "csrf": csrf})
    assert r.status_code == 302 and len(db.list_vouchers()) == 2
    codes = re.findall(r"[A-Z2-9]{4}-[A-Z2-9]{4}", host.get("/admin").get_data(as_text=True))
    assert len(set(codes)) >= 2


def test_dns_forgery():
    q = DNSRecord.question("connectivitycheck.gstatic.com", "A")
    r = DNSRecord.parse(forge_reply(q.pack(), "192.168.137.1"))
    assert r.header.id == q.header.id and str(r.rr[0].rdata) == "192.168.137.1" and r.rr[0].ttl == 5
    r6 = DNSRecord.parse(forge_reply(DNSRecord.question("x.com", "AAAA").pack(), "192.168.137.1"))
    assert r6.header.rcode == 0 and not r6.rr
