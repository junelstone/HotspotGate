; Inno Setup script - builds HotspotGate-Setup.exe from dist\HotspotGate\
#define AppName "HotspotGate"
#define AppVersion "1.0.0"
#define PortalIP "192.168.137.1"
#define Subnet "192.168.137.0/24"

[Setup]
AppId={{6B2E7C58-3F1D-4C0A-9B7E-5A1D2F9C8E41}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=HotspotGate
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=Output
OutputBaseFilename=HotspotGate-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName={#AppName}
UninstallDisplayIcon={app}\HotspotGate.exe
DisableProgramGroupPage=yes

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"

[Files]
Source: "..\dist\HotspotGate\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Dirs]
; config.json holds the Wi-Fi password and secrets: administrators and SYSTEM only
Name: "{commonappdata}\HotspotGate"; Permissions: admins-full system-full

[Icons]
Name: "{group}\HotspotGate"; Filename: "{app}\HotspotGate.exe"; WorkingDir: "{app}"
Name: "{group}\Reset admin password"; Filename: "{app}\HotspotGate.exe"; Parameters: "--reset-admin-password"; WorkingDir: "{app}"
Name: "{group}\Uninstall HotspotGate"; Filename: "{uninstallexe}"
Name: "{autodesktop}\HotspotGate"; Filename: "{app}\HotspotGate.exe"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
; Guests may reach ONLY the portal port on this PC
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""HotspotGate portal"""; Flags: runhidden
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""HotspotGate portal"" dir=in action=allow protocol=TCP localport=80 localip={#PortalIP} remoteip={#Subnet} profile=any"; Flags: runhidden
Filename: "{app}\HotspotGate.exe"; Description: "Start HotspotGate now"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""HotspotGate portal"""; Flags: runhidden; RunOnceId: "DelFirewallRule"

[UninstallDelete]
; The code database and config in %ProgramData%\HotspotGate are kept on uninstall on purpose.
Type: filesandordirs; Name: "{app}"
