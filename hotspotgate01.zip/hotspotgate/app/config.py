"""Configuration loading and first-run config generation."""
import json
import os
import secrets
import string
import sys
from pathlib import Path

from werkzeug.security import generate_password_hash

ROOT = Path(__file__).resolve().parent.parent
FROZEN = getattr(sys, "frozen", False)                       # running as the PyInstaller .exe
RESOURCE_DIR = Path(getattr(sys, "_MEIPASS", ROOT))          # bundled templates, static, scripts
# Installed app: config + database live in %ProgramData%\HotspotGate (survives upgrades).
DATA_DIR = (Path(os.environ.get("PROGRAMDATA", Path.home())) / "HotspotGate") if FROZEN else ROOT
DEFAULT_PATH = Path(os.environ.get("HOTSPOTGATE_CONFIG", DATA_DIR / "config.json"))


def resource_path(rel):
    return RESOURCE_DIR / rel

DEFAULTS = {
    "portal_ip": "192.168.137.1",      # Windows Mobile Hotspot gateway address
    "subnet": "192.168.137.0/24",
    "portal_port": 80,
    "ssid": "Guest-WiFi",
    "db_path": "data/hotspotgate.db",
    "login_max_failures": 5,           # wrong codes allowed per window, per client
    "login_window_seconds": 300,
}


def load(path=None):
    path = Path(path or DEFAULT_PATH)
    if not path.exists():
        raise SystemExit(f"Config not found: {path}\nRun:  python -m app.main --init-config")
    cfg = dict(DEFAULTS)
    cfg.update(json.loads(path.read_text(encoding="utf-8")))
    db = Path(cfg["db_path"])
    cfg["db_path"] = str(db if db.is_absolute() else DATA_DIR / db)
    Path(cfg["db_path"]).parent.mkdir(parents=True, exist_ok=True)
    return cfg


def init(path=None, force=False):
    path = Path(path or DEFAULT_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not force:
        raise SystemExit(f"{path} already exists (use --force to overwrite).")
    admin_pw = secrets.token_urlsafe(9)
    alphabet = string.ascii_letters + string.digits
    wifi_pw = "".join(secrets.choice(alphabet) for _ in range(12))
    cfg = dict(DEFAULTS)
    cfg.update({
        "passphrase": wifi_pw,
        "admin_password_hash": generate_password_hash(admin_pw),
        "secret_key": secrets.token_hex(32),
    })
    path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    print(f"Wrote {path}")
    print(f"  Admin password : {admin_pw}   (shown once - store it)")
    print(f"  Wi-Fi password : {wifi_pw}   (SSID: {cfg['ssid']})")


def reset_admin_password(path=None):
    path = Path(path or DEFAULT_PATH)
    if not path.exists():
        raise SystemExit(f"Config not found: {path}")
    cfg = json.loads(path.read_text(encoding="utf-8"))
    new_pw = secrets.token_urlsafe(9)
    cfg["admin_password_hash"] = generate_password_hash(new_pw)
    path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    print(f"New admin password: {new_pw}   (shown once - store it)")
