"""HotspotGate entry point.

  HotspotGate.exe                 run everything (installed app)
  python -m app.main --dry-run    portal only, no packet filtering (development)
"""
import argparse
import atexit
import logging
import sys
import threading
import time
import webbrowser
from pathlib import Path

from waitress import create_server

from . import config, hotspotctl
from .db import Database
from .enforcer import Enforcer
from .portal import create_app

log = logging.getLogger("hotspotgate")


def _install_close_handler(cleanup):
    """Run cleanup when the console window is closed / user logs off (Windows)."""
    if sys.platform != "win32":
        return
    import ctypes
    proto = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_uint)

    def handler(event):                      # 0=Ctrl-C 1=Ctrl-Break 2=close 5=logoff 6=shutdown
        if event in (0, 1, 2, 5, 6):
            cleanup()
        return 0
    cb = proto(handler)
    ctypes.windll.kernel32.SetConsoleCtrlHandler(cb, True)
    _install_close_handler.keep = cb         # keep a reference or it is garbage-collected


def _bind_with_retry(app, host, port, seconds=30):
    deadline = time.time() + seconds
    while True:
        try:
            return create_server(app, host=host, port=port, threads=8)
        except OSError as exc:
            if time.time() > deadline:
                raise SystemExit(f"Could not listen on {host}:{port} ({exc}). Is port {port} in use, "
                                 f"or is the hotspot off?")
            time.sleep(1)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="hotspotgate")
    ap.add_argument("--init-config", action="store_true", help="create config with fresh secrets")
    ap.add_argument("--force", action="store_true", help="overwrite config on --init-config")
    ap.add_argument("--reset-admin-password", action="store_true", help="generate a new admin password")
    ap.add_argument("--dry-run", action="store_true", help="portal only; do not filter packets")
    ap.add_argument("--no-hotspot", action="store_true", help="do not start/stop Mobile Hotspot")
    ap.add_argument("--no-browser", action="store_true", help="do not open the admin page")
    ap.add_argument("--bind", help="override bind address (testing, e.g. 127.0.0.1)")
    ap.add_argument("--config", help="path to config.json")
    args = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    cfg_path = args.config or config.DEFAULT_PATH
    if args.init_config:
        config.init(cfg_path, args.force)
        return 0
    if args.reset_admin_password:
        config.reset_admin_password(cfg_path)
        return 0

    first_run = not Path(cfg_path).exists()
    if first_run and config.FROZEN:
        config.init(cfg_path)
        print("\nWrite these down, then press Enter to start the hotspot.")
        if sys.stdin and sys.stdin.isatty():
            input()

    cfg = config.load(cfg_path)
    db = Database(cfg["db_path"])
    enforcer = Enforcer(cfg["portal_ip"], cfg["subnet"], dry_run=args.dry_run)
    manage_hotspot = sys.platform == "win32" and not (args.dry_run or args.no_hotspot)

    # Enforcement FIRST, hotspot second: guests can never be online unfiltered.
    try:
        enforcer.start()
    except Exception as exc:
        log.error("Enforcement could not start: %s", exc)
        log.error("Run as Administrator on Windows, or use --dry-run to test the portal only.")
        if config.FROZEN and sys.stdin and sys.stdin.isatty():
            input("Press Enter to close.")
        return 2

    cleaned = threading.Event()

    def cleanup():
        if cleaned.is_set():
            return
        cleaned.set()
        enforcer.stop()
        if manage_hotspot:
            ok, text = hotspotctl.run("stop", cfg_path)
            log.info("hotspot stop: %s", text if text else ("ok" if ok else "failed"))
    atexit.register(cleanup)
    _install_close_handler(cleanup)

    if manage_hotspot:
        ok, text = hotspotctl.run("start", cfg_path)
        log.info("hotspot start: %s", text)
        if not ok:
            cleanup()
            return 3

    app = create_app(cfg, db)
    host = args.bind or cfg["portal_ip"]
    server = _bind_with_retry(app, host, cfg["portal_port"])
    stop = threading.Event()

    def reaper():
        while not stop.is_set():
            if db.expire_due():
                log.info("expired sessions ended")
            enforcer.set_authorized(db.active_ips())
            stop.wait(1.0)

    enforcer.set_authorized(db.active_ips())     # restore sessions that survived a restart
    threading.Thread(target=reaper, daemon=True, name="reaper").start()
    admin_url = f"http://{host}{'' if cfg['portal_port'] == 80 else ':%s' % cfg['portal_port']}/admin"
    log.info("Running. Admin console (this PC only): %s   |   Close this window to stop.", admin_url)
    if config.FROZEN and not args.no_browser:
        threading.Timer(1.5, lambda: webbrowser.open(admin_url)).start()
    try:
        server.run()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        server.close()
        cleanup()
    return 0


if __name__ == "__main__":
    sys.exit(main())
