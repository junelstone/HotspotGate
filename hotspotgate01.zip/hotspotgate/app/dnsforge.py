"""Build the forged DNS answer that points an unauthorised client at the portal."""
from dnslib import A, DNSRecord, QTYPE, RR


def forge_reply(query_bytes, portal_ip, ttl=5):
    """A/ANY queries get the portal IP; everything else gets an empty, valid answer.

    The short TTL means the client re-resolves soon after it is authorised.
    """
    req = DNSRecord.parse(query_bytes)
    reply = req.reply()
    q = req.q
    if q.qtype in (QTYPE.A, QTYPE.ANY):
        reply.add_answer(RR(q.qname, QTYPE.A, rdata=A(portal_ip), ttl=ttl))
    return reply.pack()
