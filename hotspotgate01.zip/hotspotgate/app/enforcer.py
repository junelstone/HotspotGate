"""Packet-level enforcement using WinDivert (via pydivert). Windows + Administrator only.

Rules (all evaluated for clients inside the hotspot subnet):

  R1  DNS query -> gateway, client NOT authorised   : answer locally with the portal IP
  R2  DNS query -> gateway, client authorised       : pass through to Windows' DNS proxy
  R3  Any forwarded packet from an unauthorised IP  : drop (no internet, no DNS elsewhere)
  R4  Any forwarded packet from an authorised IP    : not captured at all -> full speed
  R5  Traffic to the portal itself (gateway:80)     : never touched; handled by the web app

Fail-closed: if the driver cannot start, start() raises and the app refuses to run.
"""
import ipaddress
import logging
import threading

from .dnsforge import forge_reply

log = logging.getLogger("hotspotgate.enforcer")


class Enforcer:
    def __init__(self, portal_ip, subnet, dry_run=False):
        self.portal_ip = portal_ip
        self.net = ipaddress.ip_network(subnet, strict=False)
        self.dry_run = dry_run
        self._auth = frozenset()
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._fwd_handle = None
        self._pd = None

    # -- public API -------------------------------------------------------
    def start(self):
        if self.dry_run:
            log.warning("DRY RUN: no packets are filtered. Do not expose real users.")
            return
        try:
            import pydivert  # imported lazily: Windows only
        except Exception as exc:
            raise RuntimeError(f"pydivert/WinDivert unavailable: {exc}") from exc
        self._pd = pydivert
        self._spawn_forward()
        threading.Thread(target=self._dns_worker, name="dns", daemon=True).start()
        log.info("Enforcement active on %s (portal %s)", self.net, self.portal_ip)

    def set_authorized(self, ips):
        ips = frozenset(ips)
        with self._lock:
            if ips == self._auth:
                return
            added, removed = ips - self._auth, self._auth - ips
            self._auth = ips
        log.info("authorised set changed: +%s -%s", sorted(added), sorted(removed))
        if not self.dry_run and self._pd:
            self._spawn_forward()      # new filter excludes the authorised IPs

    def stop(self):
        self._stop.set()
        if self._fwd_handle:
            try:
                self._fwd_handle.close()
            except Exception:
                pass

    # -- internals --------------------------------------------------------
    def _forward_filter(self):
        lo = int(self.net.network_address) + 1
        hi = int(self.net.broadcast_address) - 1
        parts = [f"ip.SrcAddr >= {ipaddress.ip_address(lo)}",
                 f"ip.SrcAddr <= {ipaddress.ip_address(hi)}"]
        parts += [f"ip.SrcAddr != {ip}" for ip in sorted(self._auth)]
        return " and ".join(parts)

    def _spawn_forward(self):
        """Open the new handle BEFORE closing the old one so there is no gap."""
        pd = self._pd
        with self._lock:
            filt = self._forward_filter()
            new = pd.WinDivert(filt, layer=pd.Layer.NETWORK_FORWARD, priority=0)
            new.open()
            old, self._fwd_handle = self._fwd_handle, new
        threading.Thread(target=self._forward_worker, args=(new,), daemon=True,
                         name="forward").start()
        if old is not None:
            try:
                old.close()
            except Exception:
                pass

    def _forward_worker(self, handle):
        """R3: swallow (drop) everything captured. The filter already excludes R4."""
        try:
            while not self._stop.is_set():
                pkt = handle.recv()
                if pkt.src_addr in self._auth:     # authorised since this filter was built
                    handle.send(pkt)
                # else: dropped by not re-injecting
        except OSError:
            pass                                   # handle closed -> superseded or stopping

    def _dns_worker(self):
        pd = self._pd
        filt = f"inbound and udp.DstPort == 53 and ip.DstAddr == {self.portal_ip}"
        with pd.WinDivert(filt, layer=pd.Layer.NETWORK, priority=0) as w:
            while not self._stop.is_set():
                try:
                    pkt = w.recv()
                except OSError:
                    break
                src = pkt.src_addr
                if src in self._auth or ipaddress.ip_address(src) not in self.net:
                    w.send(pkt)                                   # R2
                    continue
                try:
                    reply = forge_reply(bytes(pkt.payload), self.portal_ip)   # R1
                except Exception:
                    continue                                      # malformed -> drop
                pkt.src_addr, pkt.dst_addr = pkt.dst_addr, pkt.src_addr
                pkt.src_port, pkt.dst_port = pkt.dst_port, pkt.src_port
                pkt.payload = reply
                pkt.direction = pd.Direction.OUTBOUND
                w.send(pkt)
