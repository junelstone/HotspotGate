"""Captive portal + admin console (Flask)."""
import hmac
import re
import secrets
import subprocess
import time
from collections import defaultdict, deque

from flask import (Flask, abort, flash, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash

from .config import resource_path

PROBE_PATHS = {"/generate_204", "/gen_204", "/hotspot-detect.html", "/library/test/success.html",
               "/connecttest.txt", "/ncsi.txt", "/success.txt", "/canonical.html"}
MAC_RE = re.compile(r"([0-9a-f]{2}[-:]){5}[0-9a-f]{2}", re.I)


def lookup_mac(ip):
    """Best-effort MAC from the ARP table (Windows `arp -a`). Returns None on failure."""
    try:
        out = subprocess.run(["arp", "-a", ip], capture_output=True, text=True, timeout=3).stdout
    except Exception:
        return None
    for line in out.splitlines():
        if line.strip().startswith(ip + " "):
            m = MAC_RE.search(line)
            if m:
                return m.group(0).lower().replace("-", ":")
    return None


def create_app(cfg, db, mac_lookup=lookup_mac):
    app = Flask(__name__, template_folder=str(resource_path('app/templates')),
                static_folder=str(resource_path('app/static')))
    app.secret_key = cfg["secret_key"]
    app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
    portal_url = f"http://{cfg['portal_ip']}"
    local_hosts = {"127.0.0.1", "::1", cfg["portal_ip"]}
    failures = defaultdict(deque)

    # ---- helpers --------------------------------------------------------
    def throttled(ip):
        window = cfg["login_window_seconds"]
        q = failures[ip]
        while q and q[0] < time.time() - window:
            q.popleft()
        return len(q) >= cfg["login_max_failures"]

    def fmt_remaining(seconds):
        seconds = max(0, int(seconds))
        h, rem = divmod(seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h}h {m:02d}m" if h else f"{m}m {s:02d}s"
    app.jinja_env.filters["remaining"] = fmt_remaining
    app.jinja_env.filters["clock"] = lambda t: time.strftime("%d %b %H:%M", time.localtime(t)) if t else "-"

    # ---- request gate ---------------------------------------------------
    @app.before_request
    def gate():
        path = request.path
        if path.startswith("/admin"):
            if request.remote_addr not in local_hosts:
                abort(404)                      # admin is reachable from the host PC only
            return None
        if path.startswith("/static") or path in ("/login", "/status", "/logout"):
            return None
        # Anything else: connectivity probes and random sites an unauthorised phone tries.
        if db.active_by_ip(request.remote_addr):
            if path in PROBE_PATHS:
                return ("", 204) if "204" in path else ("Success", 200)
            return redirect(url_for("status"))
        return redirect(f"{portal_url}/login", code=302)

    @app.after_request
    def no_cache(resp):
        resp.headers["Cache-Control"] = "no-store"
        return resp

    # ---- guest pages ----------------------------------------------------
    @app.get("/login")
    def login():
        if db.active_by_ip(request.remote_addr):
            return redirect(url_for("status"))
        return render_template("login.html", ssid=cfg["ssid"])

    @app.post("/login")
    def login_post():
        ip = request.remote_addr
        if throttled(ip):
            return render_template("login.html", ssid=cfg["ssid"],
                                   error="Too many wrong codes. Wait a few minutes and try again."), 429
        session_row, err = db.redeem(request.form.get("code", ""), ip, mac_lookup(ip))
        if err:
            failures[ip].append(time.time())
            msg = {"invalid": "That code isn't valid. Check it and try again.",
                   "used": "That code has already been used."}[err]
            return render_template("login.html", ssid=cfg["ssid"], error=msg), 400
        return redirect(url_for("status"))

    @app.get("/status")
    def status():
        s = db.active_by_ip(request.remote_addr)
        if not s:
            return redirect(url_for("login"))
        return render_template("status.html", left=s["expires_at"] - int(time.time()))

    @app.post("/logout")
    def logout():
        s = db.active_by_ip(request.remote_addr)
        if s:
            db.end_session(s["id"], "logout")
        return redirect(url_for("login"))

    # ---- admin ----------------------------------------------------------
    def need_admin():
        if not session.get("admin"):
            return redirect(url_for("admin_login"))
        return None

    def check_csrf():
        if not hmac.compare_digest(request.form.get("csrf", ""), session.get("csrf", "x")):
            abort(400)

    @app.route("/admin/login", methods=["GET", "POST"])
    def admin_login():
        if request.method == "POST":
            if check_password_hash(cfg["admin_password_hash"], request.form.get("password", "")):
                session.clear()
                session["admin"] = True
                session["csrf"] = secrets.token_hex(16)
                return redirect(url_for("admin"))
            flash("Wrong password.")
        return render_template("admin_login.html")

    @app.get("/admin")
    def admin():
        r = need_admin()
        if r:
            return r
        now = int(time.time())
        sessions = db.active_sessions()
        for s in sessions:
            s["left"] = s["expires_at"] - now
        return render_template("admin.html", sessions=sessions, vouchers=db.list_vouchers(),
                               new_codes=session.pop("new_codes", None), csrf=session["csrf"])

    @app.post("/admin/vouchers")
    def admin_vouchers():
        r = need_admin()
        if r:
            return r
        check_csrf()
        try:
            codes = db.create_vouchers(request.form.get("count", 1), request.form.get("minutes", 60),
                                       request.form.get("note", ""))
        except ValueError:
            flash("Enter whole numbers for quantity and minutes.")
            return redirect(url_for("admin"))
        session["new_codes"] = {"codes": codes, "minutes": request.form.get("minutes", "60")}
        return redirect(url_for("admin"))

    @app.post("/admin/sessions/<int:sid>/end")
    def admin_end(sid):
        r = need_admin()
        if r:
            return r
        check_csrf()
        db.end_session(sid, "admin")
        return redirect(url_for("admin"))

    @app.post("/admin/logout")
    def admin_logout():
        session.clear()
        return redirect(url_for("admin_login"))

    return app
