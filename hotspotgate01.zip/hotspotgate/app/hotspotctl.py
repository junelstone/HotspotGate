"""Start/stop Windows Mobile Hotspot by running the bundled scripts/hotspot.ps1."""
import logging
import subprocess
import sys

from .config import resource_path

log = logging.getLogger("hotspotgate.hotspot")


def run(action, config_path):
    """action: start | stop | status. Returns (ok, text)."""
    if sys.platform != "win32":
        return False, "Mobile Hotspot control is Windows-only"
    cmd = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
           str(resource_path("scripts/hotspot.ps1")), "-Action", action, "-ConfigPath", str(config_path)]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=90,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception as exc:
        return False, str(exc)
    text = (r.stdout + r.stderr).strip()
    return r.returncode == 0, text
