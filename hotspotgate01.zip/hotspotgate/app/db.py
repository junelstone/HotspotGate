"""SQLite storage for vouchers and sessions. Thread-safe via one lock."""
import secrets
import sqlite3
import threading
import time

ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"   # no 0/O/1/I/L lookalikes

SCHEMA = """
CREATE TABLE IF NOT EXISTS vouchers (
    code        TEXT PRIMARY KEY,
    minutes     INTEGER NOT NULL,
    note        TEXT NOT NULL DEFAULT '',
    created_at  INTEGER NOT NULL,
    redeemed_at INTEGER
);
CREATE TABLE IF NOT EXISTS sessions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    code       TEXT NOT NULL REFERENCES vouchers(code),
    ip         TEXT NOT NULL,
    mac        TEXT,
    started_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    ended_at   INTEGER,
    end_reason TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_active ON sessions(ended_at, expires_at);
"""


def normalize_code(raw):
    code = "".join(ch for ch in (raw or "").upper() if ch.isalnum())
    return f"{code[:4]}-{code[4:]}" if len(code) == 8 else code


class Database:
    def __init__(self, path):
        self._lock = threading.RLock()
        self._c = sqlite3.connect(path, check_same_thread=False)
        self._c.row_factory = sqlite3.Row
        with self._lock:
            self._c.executescript(SCHEMA)
            self._c.commit()

    # -- vouchers ---------------------------------------------------------
    def create_vouchers(self, count, minutes, note=""):
        count = max(1, min(int(count), 500))
        minutes = max(1, min(int(minutes), 60 * 24 * 30))
        now = int(time.time())
        codes = []
        with self._lock:
            while len(codes) < count:
                raw = "".join(secrets.choice(ALPHABET) for _ in range(8))
                code = f"{raw[:4]}-{raw[4:]}"
                try:
                    self._c.execute(
                        "INSERT INTO vouchers(code, minutes, note, created_at) VALUES (?,?,?,?)",
                        (code, minutes, note[:80], now))
                    codes.append(code)
                except sqlite3.IntegrityError:
                    continue
            self._c.commit()
        return codes

    def list_vouchers(self, limit=300):
        now = int(time.time())
        with self._lock:
            rows = self._c.execute(
                """SELECT v.code, v.minutes, v.note, v.created_at, v.redeemed_at,
                          (SELECT MAX(expires_at) FROM sessions s WHERE s.code = v.code) AS expires_at
                   FROM vouchers v ORDER BY v.created_at DESC, v.code LIMIT ?""", (limit,)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            if not r["redeemed_at"]:
                d["status"] = "unused"
            elif r["expires_at"] and r["expires_at"] > now:
                d["status"] = "in use"
            else:
                d["status"] = "used up"
            out.append(d)
        return out

    # -- sessions ---------------------------------------------------------
    def redeem(self, code, ip, mac=None):
        """Return (session_dict, None) on success or (None, error_key)."""
        code = normalize_code(code)
        now = int(time.time())
        with self._lock:
            v = self._c.execute("SELECT * FROM vouchers WHERE code=?", (code,)).fetchone()
            if not v:
                return None, "invalid"
            live = self._c.execute(
                "SELECT * FROM sessions WHERE code=? AND ended_at IS NULL AND expires_at>?",
                (code, now)).fetchone()
            if v["redeemed_at"]:
                # Same device may resume a still-running session (e.g. DHCP gave it a new IP).
                if live and ((mac and live["mac"] == mac) or live["ip"] == ip):
                    self._c.execute("UPDATE sessions SET ip=?, mac=? WHERE id=?",
                                    (ip, mac or live["mac"], live["id"]))
                    self._c.commit()
                    return self._session(live["id"]), None
                return None, "used"
            self._c.execute("UPDATE vouchers SET redeemed_at=? WHERE code=?", (now, code))
            cur = self._c.execute(
                "INSERT INTO sessions(code, ip, mac, started_at, expires_at) VALUES (?,?,?,?,?)",
                (code, ip, mac, now, now + v["minutes"] * 60))
            self._c.commit()
            return self._session(cur.lastrowid), None

    def _session(self, sid):
        r = self._c.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone()
        return dict(r) if r else None

    def active_sessions(self):
        now = int(time.time())
        with self._lock:
            rows = self._c.execute(
                "SELECT * FROM sessions WHERE ended_at IS NULL AND expires_at>? ORDER BY started_at DESC",
                (now,)).fetchall()
        return [dict(r) for r in rows]

    def active_by_ip(self, ip):
        now = int(time.time())
        with self._lock:
            r = self._c.execute(
                "SELECT * FROM sessions WHERE ip=? AND ended_at IS NULL AND expires_at>? "
                "ORDER BY id DESC LIMIT 1", (ip, now)).fetchone()
        return dict(r) if r else None

    def active_ips(self):
        return {s["ip"] for s in self.active_sessions()}

    def end_session(self, sid, reason="ended"):
        with self._lock:
            self._c.execute(
                "UPDATE sessions SET ended_at=?, end_reason=? WHERE id=? AND ended_at IS NULL",
                (int(time.time()), reason, sid))
            self._c.commit()

    def expire_due(self):
        with self._lock:
            cur = self._c.execute(
                "UPDATE sessions SET ended_at=?, end_reason='expired' "
                "WHERE ended_at IS NULL AND expires_at<=?", (int(time.time()),) * 2)
            self._c.commit()
            return cur.rowcount
