<#
 One-time setup. Run from an elevated (Administrator) PowerShell:
     powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1
#>
$ErrorActionPreference = 'Stop'
$root = Resolve-Path (Join-Path $PSScriptRoot '..')
Set-Location $root

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { throw 'Run this script as Administrator (right-click PowerShell > Run as administrator).' }

# 1. Python 3.10+
$pyExe  = if (Get-Command py -ErrorAction SilentlyContinue) { 'py' } else { 'python' }
$pyArgs = if ($pyExe -eq 'py') { @('-3') } else { @() }
$ver = & $pyExe @pyArgs -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
if (-not $ver -or [version]$ver -lt [version]'3.10') { throw "Python 3.10+ is required (found: '$ver'). Install it from python.org." }

# 2. Virtual environment + dependencies
if (-not (Test-Path .venv)) { & $pyExe @pyArgs -m venv .venv }
& .\.venv\Scripts\python.exe -m pip install --upgrade pip --quiet
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt --quiet

# 3. Config with fresh random secrets (never overwrites an existing one)
if (-not (Test-Path config.json)) { & .\.venv\Scripts\python.exe -m app.main --init-config }
else { Write-Host 'config.json already exists - keeping it.' }

# 4. Firewall: let hotspot guests reach ONLY the portal port, nothing else on this PC
$cfg = Get-Content config.json -Raw | ConvertFrom-Json
Get-NetFirewallRule -DisplayName 'HotspotGate portal' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
New-NetFirewallRule -DisplayName 'HotspotGate portal' -Direction Inbound -Action Allow -Protocol TCP `
    -LocalPort $cfg.portal_port -LocalAddress $cfg.portal_ip -RemoteAddress $cfg.subnet -Profile Any | Out-Null
Write-Host "Firewall rule created: TCP $($cfg.portal_port) on $($cfg.portal_ip) from $($cfg.subnet)"

Write-Host "`nSetup complete. Start everything with:  .\scripts\run.ps1"
Write-Host "Then open http://$($cfg.portal_ip)/admin on this PC to create access codes."
