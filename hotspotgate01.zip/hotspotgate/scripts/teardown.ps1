<# Remove the firewall rule and make sure the hotspot is off. Run as Administrator. #>
Get-NetFirewallRule -DisplayName 'HotspotGate portal' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'hotspot.ps1') stop
Write-Host 'Done. Delete this folder to remove HotspotGate completely (data\ holds the code database).'
