<#
 Build HotspotGate.exe (PyInstaller) and, if Inno Setup is installed, the installer:
     powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1
 Output:  dist\HotspotGate\HotspotGate.exe   and   installer\Output\HotspotGate-Setup.exe
 Needs: Windows, Python 3.10+.  Installer step needs Inno Setup 6 (winget install JRSoftware.InnoSetup).
#>
$ErrorActionPreference = 'Stop'
Set-Location (Resolve-Path (Join-Path $PSScriptRoot '..'))

$pyExe  = if (Get-Command py -ErrorAction SilentlyContinue) { 'py' } else { 'python' }
$pyArgs = if ($pyExe -eq 'py') { @('-3') } else { @() }
if (-not (Test-Path .venv-build)) { & $pyExe @pyArgs -m venv .venv-build }
$py = '.\.venv-build\Scripts\python.exe'
& $py -m pip install --upgrade pip --quiet
& $py -m pip install -r requirements.txt pyinstaller --quiet

Remove-Item -Recurse -Force build, dist -ErrorAction SilentlyContinue
& $py -m PyInstaller --noconfirm --clean --onedir --console `
    --name HotspotGate --uac-admin `
    --add-data "app\templates;app\templates" `
    --add-data "app\static;app\static" `
    --add-data "scripts\hotspot.ps1;scripts" `
    --collect-all pydivert `
    run_app.py
if (-not (Test-Path dist\HotspotGate\HotspotGate.exe)) { throw 'PyInstaller did not produce HotspotGate.exe' }
Write-Host "Built dist\HotspotGate\HotspotGate.exe"

$iscc = @("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe") |
        Where-Object { Test-Path $_ } | Select-Object -First 1
if ($iscc) {
    & $iscc installer\HotspotGate.iss
    Write-Host "Built installer\Output\HotspotGate-Setup.exe"
} else {
    Write-Warning 'Inno Setup 6 not found - skipped installer. Install it (winget install JRSoftware.InnoSetup) and re-run.'
}
