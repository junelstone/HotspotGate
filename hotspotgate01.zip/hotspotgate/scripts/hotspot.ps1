<#
 Start / stop / inspect Windows Mobile Hotspot using the built-in WinRT tethering API.
 Must run in Windows PowerShell 5.1 (powershell.exe) - PowerShell 7 has no WinRT projection.
 Reads ssid / passphrase from -ConfigPath (default ..\config.json).
#>
param(
  [Parameter(Mandatory)][ValidateSet('start','stop','status')][string]$Action,
  [string]$ConfigPath = (Join-Path $PSScriptRoot '..\config.json')
)
$ErrorActionPreference = 'Stop'

$cfg = Get-Content $ConfigPath -Raw | ConvertFrom-Json

Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Networking.Connectivity.NetworkInformation, Windows.Networking.Connectivity, ContentType = WindowsRuntime]
$null = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager, Windows.Networking.NetworkOperators, ContentType = WindowsRuntime]
$null = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringAccessPointConfiguration, Windows.Networking.NetworkOperators, ContentType = WindowsRuntime]

$ext   = [System.WindowsRuntimeSystemExtensions].GetMethods()
$asOp  = ($ext | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
$asAct = ($ext | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' })[0]
function Wait-Op($op, $type) { $t = $asOp.MakeGenericMethod($type).Invoke($null, @($op)); $null = $t.Wait(-1); $t.Result }
function Wait-Act($act)      { $t = $asAct.Invoke($null, @($act)); $null = $t.Wait(-1) }

$profile = [Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
if (-not $profile) { throw 'No internet connection to share. Connect this PC to the internet first (Ethernet or Wi-Fi).' }
$mgr = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager]::CreateFromConnectionProfile($profile)
$resultType = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult]

switch ($Action) {
  'status' {
    "State: $($mgr.TetheringOperationalState)   Clients: $($mgr.ClientCount)   Max: $($mgr.MaxClientCount)"
  }
  'start' {
    if ($mgr.TetheringOperationalState -ne 'On') {
      if ($cfg.passphrase.Length -lt 8) { throw 'Wi-Fi passphrase in config.json must be at least 8 characters.' }
      $ap = $mgr.GetCurrentAccessPointConfiguration()
      $ap.Ssid = $cfg.ssid
      $ap.Passphrase = $cfg.passphrase
      Wait-Act ($mgr.ConfigureAccessPointAsync($ap))
      $r = Wait-Op ($mgr.StartTetheringAsync()) $resultType
      if ($r.Status -ne 'Success') { throw "Could not start hotspot: $($r.Status) $($r.AdditionalErrorMessage)" }
    }
    "Hotspot '$($cfg.ssid)' is ON  ($($mgr.TetheringOperationalState))"
  }
  'stop' {
    if ($mgr.TetheringOperationalState -ne 'Off') {
      $r = Wait-Op ($mgr.StopTetheringAsync()) $resultType
      if ($r.Status -ne 'Success') { throw "Could not stop hotspot: $($r.Status)" }
    }
    'Hotspot is OFF'
  }
}
