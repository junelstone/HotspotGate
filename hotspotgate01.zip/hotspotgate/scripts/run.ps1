<#
 Developer launcher: run from source (the installed app uses HotspotGate.exe instead).
 Self-elevates to Administrator. The app itself starts the hotspot after enforcement is up
 and stops it again on exit.
#>
$root = Resolve-Path (Join-Path $PSScriptRoot '..')
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoExit -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    return
}
Set-Location $root
try     { & .\.venv\Scripts\python.exe -m app.main }
finally { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'hotspot.ps1') -Action stop }
